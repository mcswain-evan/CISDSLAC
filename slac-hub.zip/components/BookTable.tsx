
import React, { useState } from 'react';
import { Book, ComplianceLevel, GradeStatus } from '../types';
import { CheckIcon, InfoIcon, ExclamationTriangleIcon } from './Icons';

interface BookTableProps {
  books: Book[];
}

const GradeBadge: React.FC<{ label: string; gradeData: GradeStatus }> = ({ label, gradeData }) => {
  const getColors = (status: ComplianceLevel) => {
    switch (status) {
      case 'GREEN': return 'bg-emerald-500 text-white';
      case 'YELLOW': return 'bg-amber-500 text-white';
      case 'RED': return 'bg-red-600 text-white';
      default: return 'bg-gray-200 text-gray-500';
    }
  };

  return (
    <div className="flex items-center justify-between w-full px-2 py-1 bg-gray-50 border border-gray-100 rounded-sm mb-1 group relative">
      <span className="text-[9px] font-black uppercase tracking-tighter text-gray-400">{label}</span>
      <div className={`w-2 h-2 rounded-full ${getColors(gradeData.status)} shadow-sm`}></div>
      {/* Tooltip on hover */}
      <div className="absolute left-full ml-2 hidden group-hover:block z-50 w-48 bg-[#212121] text-white p-3 rounded-sm text-[10px] font-medium leading-tight shadow-xl">
        <div className="font-bold mb-1 border-b border-white/20 pb-1">{label} Compliance</div>
        {gradeData.reason}
      </div>
    </div>
  );
};

const BookTable: React.FC<BookTableProps> = ({ books }) => {
  const [expandedId, setExpandedId] = useState<number | null>(null);

  if (books.length === 0) {
    return (
      <div className="p-20 text-center text-gray-400 font-bold heading-font text-2xl tracking-widest">
        NO MATERIALS FOUND FOR AUDIT
      </div>
    );
  }

  return (
    <div className="overflow-x-auto">
      <table className="w-full text-left border-collapse">
        <thead>
          <tr className="bg-gray-50 border-b-2 border-gray-200">
            <th className="px-8 py-5 text-xs font-bold text-gray-600 uppercase tracking-[0.15em] heading-font">Instructional Material</th>
            <th className="px-8 py-5 text-xs font-bold text-gray-600 uppercase tracking-[0.15em] heading-font text-center w-40">Audit Breakdown</th>
            <th className="px-8 py-5 text-xs font-bold text-gray-600 uppercase tracking-[0.15em] heading-font">Material Specs</th>
            <th className="px-8 py-5 text-xs font-bold text-gray-600 uppercase tracking-[0.15em] heading-font">Primary Themes</th>
            <th className="px-8 py-5 text-xs font-bold text-gray-600 uppercase tracking-[0.15em] heading-font">Review</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-gray-100">
          {books.map((book, idx) => (
            <React.Fragment key={idx}>
              <tr 
                className={`hover:bg-gray-50/80 transition-colors cursor-pointer border-l-4 ${expandedId === idx ? 'border-[#841A2B] bg-gray-50' : 'border-transparent'}`}
                onClick={() => setExpandedId(expandedId === idx ? null : idx)}
              >
                <td className="px-8 py-6">
                  <div className="font-bold text-gray-900 text-lg leading-tight uppercase tracking-tight">{book.title}</div>
                  <div className="text-gray-500 text-sm mt-1 font-semibold">{book.author}</div>
                </td>
                <td className="px-8 py-6">
                  <div className="flex flex-col w-32 mx-auto">
                    <GradeBadge label="Elementary" gradeData={book.gradeCompliance.elementary} />
                    <GradeBadge label="Intermediate" gradeData={book.gradeCompliance.intermediate} />
                    <GradeBadge label="High School" gradeData={book.gradeCompliance.highSchool} />
                  </div>
                </td>
                <td className="px-8 py-6">
                  <div className="text-xs text-gray-500 space-y-1 font-bold">
                    <div className="uppercase">Pub: {book.pubDate}</div>
                    <div className="text-gray-900">{book.pageCount} Pages</div>
                  </div>
                </td>
                <td className="px-8 py-6">
                  <div className="flex flex-wrap gap-2">
                    {book.themes.slice(0, 3).map((theme, i) => (
                      <span key={i} className="px-2 py-1 bg-[#841A2B]/5 text-[#841A2B] text-[10px] font-bold rounded-sm border border-[#841A2B]/10 uppercase tracking-tighter">
                        {theme}
                      </span>
                    ))}
                  </div>
                </td>
                <td className="px-8 py-6">
                  <div className="flex items-center space-x-5">
                    <a 
                      href={book.goodreadsUrl} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="text-[#841A2B] hover:text-[#6d1523] text-[11px] font-bold uppercase tracking-widest underline underline-offset-4"
                      onClick={(e) => e.stopPropagation()}
                    >
                      Audit Ref
                    </a>
                    <button className="text-gray-400 hover:text-[#841A2B] transition-colors">
                      <InfoIcon className={`w-6 h-6 transition-transform duration-300 ${expandedId === idx ? 'rotate-180 text-[#841A2B]' : ''}`} />
                    </button>
                  </div>
                </td>
              </tr>
              {expandedId === idx && (
                <tr className="bg-white">
                  <td colSpan={5} className="px-12 py-10 border-b border-gray-200 shadow-inner">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
                      <div className="space-y-6">
                        <h4 className="text-xs font-bold text-gray-900 border-b-2 border-gray-100 pb-3 uppercase tracking-widest heading-font">Audit Summary & Rationale</h4>
                        <div className="p-6 bg-gray-50 rounded-sm border-l-4 border-[#841A2B] shadow-sm">
                          <p className="text-sm text-gray-700 leading-relaxed font-medium italic mb-4">
                            "{book.complianceReason}"
                          </p>
                          <div className="space-y-3 pt-4 border-t border-gray-200">
                             <div className="flex items-start space-x-2">
                                <span className="text-[10px] font-black text-gray-400 uppercase w-20">Elementary:</span>
                                <span className="text-[11px] font-medium text-gray-600">{book.gradeCompliance.elementary.reason}</span>
                             </div>
                             <div className="flex items-start space-x-2">
                                <span className="text-[10px] font-black text-gray-400 uppercase w-20">Intermediate:</span>
                                <span className="text-[11px] font-medium text-gray-600">{book.gradeCompliance.intermediate.reason}</span>
                             </div>
                             <div className="flex items-start space-x-2">
                                <span className="text-[10px] font-black text-gray-400 uppercase w-20">High School:</span>
                                <span className="text-[11px] font-medium text-gray-600">{book.gradeCompliance.highSchool.reason}</span>
                             </div>
                          </div>
                        </div>
                        <div className="flex items-center space-x-3 text-[10px] font-bold text-gray-400 uppercase tracking-widest">
                          <div className="w-2 h-2 rounded-full bg-[#841A2B]"></div>
                          <span>Canyon ISD Instructional Materials Review</span>
                        </div>
                      </div>
                      <div className="space-y-6">
                        <h4 className="text-xs font-bold text-gray-900 border-b-2 border-gray-100 pb-3 uppercase tracking-widest heading-font">Rubric Thematic Ratings</h4>
                        <div className="grid grid-cols-2 gap-x-6 gap-y-3">
                          {book.detailedRatings.map((r, i) => (
                            <div key={i} className="flex items-center justify-between text-[11px] py-2 border-b border-gray-50 last:border-0 font-bold uppercase">
                              <span className="text-gray-500">{r.theme}</span>
                              <span className={`px-2 py-0.5 rounded-sm ${r.rating === 'P' || r.rating === 'C' ? 'bg-red-600 text-white' : 'bg-gray-200 text-gray-700'}`}>
                                {r.rating}
                              </span>
                            </div>
                          ))}
                        </div>
                        <div className="bg-[#212121] text-white p-4 rounded-sm text-[10px] font-bold uppercase tracking-widest leading-loose">
                          Rating Matrix: N=None, M=Minimal, S=Some, C=Common, P=Prevalent
                        </div>
                      </div>
                    </div>
                  </td>
                </tr>
              )}
            </React.Fragment>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default BookTable;
