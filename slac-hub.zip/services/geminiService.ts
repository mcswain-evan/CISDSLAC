
import { GoogleGenAI, GenerateContentResponse, Type } from "@google/genai";
import { BookResult, Book } from "../types";

export async function fetchBookData(titles: string[]): Promise<BookResult> {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  const prompt = `
    Analyze the following list of books: ${titles.join(", ")}.
    Perform a deep search using sites like Goodreads, Kirkus Reviews, and Booklist to evaluate them against the "Canyon ISD Library Material Review Rubric" and Texas SB 13 requirements.

    For each book, determine:
    1. Metadata: Author, Pub Date, Page Count, Themes, Goodreads URL.
    2. Content Ratings (N=None, M=Minimal, S=Some, C=Common, P=Prevalent) for 13 themes: Profanity, Kissing, Horror, Violence, Bullying, Minor Drug Use, Minor Tobacco Use, Adult Drug Use, Suicide/Self-Harm, Nonsexual Nudity, Nude Body Parts (PROHIBITED), Sexually Explicit Conduct (PROHIBITED), Sex Scenes.
    
    3. Grade Level Compliance Evaluation:
       Determine if the book is compliant (GREEN), needs review (YELLOW), or is non-compliant/prohibited (RED) for each specific grade level:
       - Elementary (Grades PK-4)
       - Intermediate (Grades 5-8)
       - High School (Grades 9-12)

    Compliance Rules:
    - RED: Contains PROHIBITED content (nude intimate parts or sexually explicit conduct) or Prevalent (P) sex scenes. This is RED for ALL grade levels.
    - YELLOW/RED: Content that might be acceptable for High School but prohibited for Elementary (e.g., Common (C) profanity or Some (S) violence).
    - GREEN: Age-appropriate content with Minimal (M) or None (N) thematic concerns.

    IMPORTANT: Respond ONLY with a JSON array of objects.
  `;

  try {
    const response: GenerateContentResponse = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
      config: {
        tools: [{ googleSearch: {} }],
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              title: { type: Type.STRING },
              author: { type: Type.STRING },
              pubDate: { type: Type.STRING },
              pageCount: { type: Type.STRING },
              themes: { type: Type.ARRAY, items: { type: Type.STRING } },
              goodreadsUrl: { type: Type.STRING },
              complianceStatus: { type: Type.STRING },
              complianceReason: { type: Type.STRING },
              detailedRatings: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    theme: { type: Type.STRING },
                    rating: { type: Type.STRING }
                  },
                  required: ["theme", "rating"]
                }
              },
              gradeCompliance: {
                type: Type.OBJECT,
                properties: {
                  elementary: {
                    type: Type.OBJECT,
                    properties: {
                      status: { type: Type.STRING },
                      reason: { type: Type.STRING }
                    },
                    required: ["status", "reason"]
                  },
                  intermediate: {
                    type: Type.OBJECT,
                    properties: {
                      status: { type: Type.STRING },
                      reason: { type: Type.STRING }
                    },
                    required: ["status", "reason"]
                  },
                  highSchool: {
                    type: Type.OBJECT,
                    properties: {
                      status: { type: Type.STRING },
                      reason: { type: Type.STRING }
                    },
                    required: ["status", "reason"]
                  }
                },
                required: ["elementary", "intermediate", "highSchool"]
              }
            },
            required: ["title", "author", "pubDate", "pageCount", "themes", "goodreadsUrl", "complianceStatus", "complianceReason", "detailedRatings", "gradeCompliance"]
          }
        }
      },
    });

    const text = response.text || "[]";
    let books: Book[] = [];
    
    try {
      books = JSON.parse(text);
    } catch (e) {
      const jsonMatch = text.match(/\[\s*\{.*\}\s*\]/s);
      if (jsonMatch) books = JSON.parse(jsonMatch[0]);
    }

    const groundingChunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks || [];
    const sources = groundingChunks
      .filter(chunk => chunk.web)
      .map(chunk => ({
        title: chunk.web?.title,
        uri: chunk.web?.uri
      }));

    return { books, sources };
  } catch (error) {
    console.error("Gemini API Error:", error);
    throw error;
  }
}
